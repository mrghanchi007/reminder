# AlertPro+ - Smart Alarm & Reminder PWA

A fully installable Progressive Web App (PWA) designed as a smart alarm and reminder system with offline capability, advanced alarm features, and modern UI.

## Features

### Core Functionality
- 📅 **Calendar View** - Monthly calendar displaying all reminders
- 📋 **Timeline View** - Chronological list of upcoming reminders
- ⏰ **Smart Alarms** - Advanced alarm system with multiple tones
- 🎵 **Audio Control** - Volume levels (10%, 25%, 50%, 100%) with silent mode bypass
- 🔄 **Repeat Options** - Once, daily, weekly, monthly, or custom patterns
- 📳 **Vibration Support** - Configurable vibration patterns
- ⏱️ **Snooze Function** - 5, 10, 15-minute snooze delays

### PWA Features
- 📱 **Fully Installable** - Install on mobile and desktop
- 🔄 **Offline Capability** - Works without internet connection
- 🌙 **Dark/Light Theme** - Automatic theme switching
- 📊 **Data Export/Import** - Backup and restore reminders
- 🔒 **Local Storage** - All data stored securely on device

### Advanced Features
- 🚨 **Priority Levels** - High priority alarms bypass silent mode
- 🎼 **Multiple Tones** - Default, Classic, Melody, Urgent alarm sounds
- 💤 **Wake Lock** - Keeps screen active during alarms
- 📱 **Responsive Design** - Optimized for all screen sizes
- ⚡ **Performance** - Fast loading with service worker caching

## Tech Stack

### Frontend
- **React 18** with TypeScript
- **Vite** for build tooling
- **Tailwind CSS** for styling
- **Shadcn/UI** components
- **Framer Motion** for animations
- **React Query** for state management

### Backend
- **Express.js** with TypeScript
- **Drizzle ORM** for database schema
- **In-memory storage** (ready for PostgreSQL)

### PWA Technologies
- **Service Worker** for offline caching
- **Web App Manifest** for installation
- **Web Audio API** for advanced sound control
- **Wake Lock API** for screen management
- **Vibration API** for haptic feedback
- **IndexedDB** via Dexie.js for local storage

## Installation & Setup

### Prerequisites
- Node.js 18 or higher
- npm or yarn package manager

### Quick Start
```bash
# Clone the repository
git clone https://github.com/yourusername/alertpro-plus.git
cd alertpro-plus

# Install dependencies
npm install

# Start development server
npm run dev
```

The app will be available at `http://localhost:5000`

### Production Build
```bash
# Build for production
npm run build

# Preview production build
npm run preview
```

## Project Structure

```
alertpro-plus/
├── client/                 # Frontend React app
│   ├── public/            # Static assets & PWA files
│   ├── src/
│   │   ├── components/    # React components
│   │   ├── hooks/         # Custom React hooks
│   │   ├── lib/           # Utilities and managers
│   │   ├── pages/         # Route components
│   │   └── types/         # TypeScript definitions
├── server/                # Backend Express app
├── shared/                # Shared schemas and types
└── package.json          # Dependencies and scripts
```

## Key Components

### Reminder Management
- **NewReminderModal** - Create and edit reminders
- **CalendarView** - Monthly calendar interface
- **TimelineView** - Chronological reminder list
- **AlarmModal** - Fullscreen alarm interface

### System Components
- **AlarmScheduler** - Handles reminder scheduling
- **AudioManager** - Advanced audio control
- **WakeLock** - Screen management during alarms
- **ServiceWorker** - Offline functionality

## Configuration

### PWA Configuration
The app includes a complete PWA setup with:
- Web App Manifest (`client/public/manifest.json`)
- Service Worker for offline caching
- Icons for all platforms (192x192, 512x512)
- Proper meta tags for installation

### Audio Configuration
Built-in alarm tones included as data URLs for offline use:
- Default - Standard alarm tone
- Classic - Traditional alarm sound
- Melody - Pleasant musical tone
- Urgent - High-attention alarm

## Browser Support

- Chrome 80+ (recommended)
- Firefox 75+
- Safari 13+
- Edge 80+

### Required APIs
- Web Audio API
- Service Worker
- IndexedDB
- Wake Lock API (optional)
- Vibration API (optional)

## Development

### Available Scripts
- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run type-check` - Run TypeScript checks

### Adding New Features
1. Create components in `client/src/components/`
2. Add API endpoints in `server/routes.ts`
3. Update database schema in `shared/schema.ts`
4. Add new types in `client/src/types/`

## Deployment

### Replit Deployment
This project is optimized for Replit deployment:
1. Import project to Replit
2. Install dependencies automatically
3. Use "Deploy" button for production

### Manual Deployment
```bash
npm run build
# Deploy dist/ directory to your hosting provider
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

MIT License - see LICENSE file for details

## Support

For issues and feature requests, please use the GitHub Issues page.

---

**Built with ❤️ using React, TypeScript, and modern PWA technologies**