# AlertPro+ - Smart Alarm & Reminder PWA

## Overview

AlertPro+ is a fully installable, offline-capable Progressive Web App (PWA) designed as a smart alarm and reminder system. The application features a modern, responsive interface with dark/light theme support, advanced alarm functionality including silent mode bypass, and comprehensive reminder management capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: Shadcn/UI components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **State Management**: React Query for server state, React hooks for local state
- **Routing**: Wouter for lightweight client-side routing
- **Animations**: Framer Motion for smooth UI transitions

### Backend Architecture
- **Server**: Express.js with TypeScript
- **Development Setup**: Vite middleware integration for hot reloading
- **API Structure**: RESTful endpoints with `/api` prefix
- **Storage Interface**: Abstract storage layer with in-memory implementation

### PWA Features
- **Service Worker**: Custom implementation for offline caching
- **Web App Manifest**: Complete PWA configuration with icons and shortcuts
- **Installation**: Fully installable on mobile and desktop platforms
- **Offline Capability**: Static and dynamic resource caching

## Key Components

### Core UI Components
- **Home Page**: Main dashboard with calendar and timeline views
- **Calendar View**: Monthly calendar displaying reminders
- **Timeline View**: Chronological list of upcoming reminders
- **New Reminder Modal**: Form for creating reminders with advanced options
- **Settings Modal**: App configuration and data management
- **Alarm Modal**: Fullscreen alarm interface with snooze/stop controls

### Reminder Management
- **Title and Description**: Basic reminder information
- **Date/Time Picker**: Scheduling interface
- **Repeat Options**: Once, daily, weekly, monthly, or custom patterns
- **Alarm Tones**: Selectable audio tones (default, classic, melody, urgent)
- **Volume Control**: 10%, 25%, 50%, 100% volume levels
- **Priority Levels**: Normal and high priority (silent mode bypass)
- **Vibration Support**: Toggle vibration patterns
- **Snooze Configuration**: 5, 10, 15-minute snooze delays

### Advanced Alarm Features
- **Web Audio API**: Advanced audio control with gain nodes
- **Wake Lock API**: Keeps screen active during alarms
- **Vibration API**: Configurable vibration patterns
- **Silent Mode Bypass**: High-priority alarms play at maximum volume
- **Visual Alerts**: Flashing UI elements for accessibility

## Data Flow

### Client-Side Data Management
1. **IndexedDB Storage**: Using Dexie.js for local data persistence
2. **React Query**: Caching and synchronization of reminder data
3. **Real-time Scheduling**: JavaScript-based alarm scheduler
4. **Settings Persistence**: Local storage for user preferences

### Alarm Trigger Flow
1. Reminder scheduled using setTimeout for precise timing
2. Wake Lock API activated to prevent screen sleep
3. Audio context initialized and alarm tone played in loop
4. Visual feedback with fullscreen modal
5. Vibration API triggered if enabled
6. User interaction required to stop or snooze

### Data Synchronization
- Local-first approach with IndexedDB as primary storage
- Future-ready for server synchronization
- Export/import functionality for data portability

## External Dependencies

### Core Libraries
- **React Ecosystem**: React, React DOM, React Query
- **UI Framework**: Radix UI primitives, Tailwind CSS
- **Database**: Dexie.js for IndexedDB abstraction
- **Audio Management**: Web Audio API with fallback to HTML5 Audio
- **Date Handling**: date-fns for date manipulation
- **Validation**: Zod for schema validation

### PWA Dependencies
- **Service Worker**: Custom implementation for caching strategies
- **Web APIs**: Wake Lock, Vibration, Notification APIs
- **Installation**: Web App Manifest with proper icons and metadata

### Development Tools
- **Build System**: Vite with TypeScript support
- **Backend**: Express.js with development middleware
- **Database Schema**: Drizzle ORM for future database integration
- **Code Quality**: TypeScript strict mode, ESLint configuration

## Deployment Strategy

### Production Build
- **Frontend**: Vite builds optimized React application to `dist/public`
- **Backend**: esbuild compiles Express server to `dist/index.js`
- **Static Assets**: Service worker and manifest files served from public directory

### Environment Configuration
- **Development**: Vite dev server with Express API integration
- **Production**: Express serves static files and API endpoints
- **Database**: Currently configured for PostgreSQL with Drizzle ORM (ready for future use)

### PWA Deployment Considerations
- HTTPS required for service worker and advanced Web APIs
- Proper cache headers for offline functionality
- Web App Manifest served with correct MIME type
- Service worker registration and update handling

The application is architected as a client-heavy PWA with local data storage, designed to work offline while providing a native app-like experience. The backend serves as an API layer ready for future enhancements like user authentication and cloud synchronization.