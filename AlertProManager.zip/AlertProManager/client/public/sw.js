const CACHE_NAME = 'alertpro-v1.0.0';
const STATIC_CACHE = 'alertpro-static-v1.0.0';
const DYNAMIC_CACHE = 'alertpro-dynamic-v1.0.0';

// Resources to cache immediately
const STATIC_ASSETS = [
  '/',
  '/manifest.json',
  '/src/main.tsx',
  '/src/index.css',
  '/src/App.tsx'
];

// Install event - cache static assets
self.addEventListener('install', (event) => {
  console.log('Service Worker: Installing...');
  
  event.waitUntil(
    caches.open(STATIC_CACHE)
      .then((cache) => {
        console.log('Service Worker: Caching static assets');
        return cache.addAll(STATIC_ASSETS);
      })
      .then(() => {
        console.log('Service Worker: Static assets cached');
        return self.skipWaiting();
      })
      .catch((error) => {
        console.error('Service Worker: Failed to cache static assets', error);
      })
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
  console.log('Service Worker: Activating...');
  
  event.waitUntil(
    caches.keys()
      .then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cacheName) => {
            if (cacheName !== STATIC_CACHE && cacheName !== DYNAMIC_CACHE) {
              console.log('Service Worker: Deleting old cache', cacheName);
              return caches.delete(cacheName);
            }
          })
        );
      })
      .then(() => {
        console.log('Service Worker: Activated');
        return self.clients.claim();
      })
  );
});

// Fetch event - serve from cache with network fallback
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip non-GET requests
  if (request.method !== 'GET') {
    return;
  }

  // Skip chrome-extension and other non-http(s) requests
  if (!url.protocol.startsWith('http')) {
    return;
  }

  // Handle API requests
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(
      fetch(request)
        .then((response) => {
          // Clone response for caching
          const responseClone = response.clone();
          
          // Cache successful responses
          if (response.ok) {
            caches.open(DYNAMIC_CACHE)
              .then((cache) => {
                cache.put(request, responseClone);
              });
          }
          
          return response;
        })
        .catch(() => {
          // Return cached response if available
          return caches.match(request);
        })
    );
    return;
  }

  // Handle static assets and navigation requests
  event.respondWith(
    caches.match(request)
      .then((cachedResponse) => {
        if (cachedResponse) {
          return cachedResponse;
        }

        return fetch(request)
          .then((response) => {
            // Don't cache non-successful responses
            if (!response.ok) {
              return response;
            }

            // Clone response for caching
            const responseClone = response.clone();
            
            // Cache the response
            caches.open(DYNAMIC_CACHE)
              .then((cache) => {
                cache.put(request, responseClone);
              });

            return response;
          })
          .catch(() => {
            // For navigation requests, return the cached index.html
            if (request.mode === 'navigate') {
              return caches.match('/');
            }
            
            // For other requests, throw the error
            throw new Error('Network unavailable and no cached version found');
          });
      })
  );
});

// Background sync for alarm scheduling
self.addEventListener('sync', (event) => {
  if (event.tag === 'alarm-sync') {
    event.waitUntil(syncAlarms());
  }
});

// Handle alarm notifications
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SCHEDULE_ALARM') {
    scheduleAlarmNotification(event.data.alarm);
  }
});

// Function to sync alarms (placeholder for future implementation)
function syncAlarms() {
  console.log('Service Worker: Syncing alarms');
  return Promise.resolve();
}

// Function to schedule alarm notifications
function scheduleAlarmNotification(alarmData) {
  const now = Date.now();
  const alarmTime = new Date(alarmData.datetime).getTime();
  const delay = alarmTime - now;

  if (delay > 0) {
    setTimeout(() => {
      showAlarmNotification(alarmData);
    }, delay);
  }
}

// Function to show alarm notification
function showAlarmNotification(alarmData) {
  const options = {
    body: alarmData.description || 'Time for your reminder!',
    icon: '/manifest.json',
    badge: '/manifest.json',
    tag: `alarm-${alarmData.id}`,
    requireInteraction: true,
    actions: [
      {
        action: 'snooze',
        title: 'Snooze'
      },
      {
        action: 'dismiss',
        title: 'Dismiss'
      }
    ],
    data: alarmData
  };

  self.registration.showNotification(alarmData.title, options);
}

// Handle notification clicks
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  if (event.action === 'snooze') {
    // Handle snooze action
    const alarmData = event.notification.data;
    const snoozeTime = new Date(Date.now() + alarmData.snoozeDelay * 60 * 1000);
    scheduleAlarmNotification({ ...alarmData, datetime: snoozeTime });
  } else {
    // Open the app
    event.waitUntil(
      clients.matchAll({ type: 'window' })
        .then((clientList) => {
          for (let i = 0; i < clientList.length; i++) {
            const client = clientList[i];
            if (client.url.includes(self.location.origin) && 'focus' in client) {
              return client.focus();
            }
          }
          if (clients.openWindow) {
            return clients.openWindow('/');
          }
        })
    );
  }
});

// Handle push events (for future implementation)
self.addEventListener('push', (event) => {
  if (event.data) {
    const data = event.data.json();
    showAlarmNotification(data);
  }
});

// Error handling
self.addEventListener('error', (event) => {
  console.error('Service Worker error:', event.error);
});

self.addEventListener('unhandledrejection', (event) => {
  console.error('Service Worker unhandled rejection:', event.reason);
});
