import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Reminder } from '../types/reminder';
import { reminderService } from '../lib/db';
import { alarmScheduler } from '../lib/alarmScheduler';

export function useReminders() {
  const queryClient = useQueryClient();

  const remindersQuery = useQuery({
    queryKey: ['reminders'],
    queryFn: reminderService.getAll,
  });

  const todayRemindersQuery = useQuery({
    queryKey: ['reminders', 'today'],
    queryFn: reminderService.getTodaysReminders,
  });

  const upcomingRemindersQuery = useQuery({
    queryKey: ['reminders', 'upcoming'],
    queryFn: reminderService.getUpcomingReminders,
  });

  const createReminderMutation = useMutation({
    mutationFn: reminderService.create,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reminders'] });
      // Reschedule all alarms after creating a new one
      scheduleAllAlarms();
    },
  });

  const updateReminderMutation = useMutation({
    mutationFn: ({ id, changes }: { id: string; changes: Partial<Reminder> }) =>
      reminderService.update(id, changes),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reminders'] });
      scheduleAllAlarms();
    },
  });

  const deleteReminderMutation = useMutation({
    mutationFn: reminderService.delete,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reminders'] });
      scheduleAllAlarms();
    },
  });

  const clearAllRemindersMutation = useMutation({
    mutationFn: reminderService.clear,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reminders'] });
      alarmScheduler.cancelAllReminders();
    },
  });

  const scheduleAllAlarms = async () => {
    const reminders = await reminderService.getActive();
    alarmScheduler.cancelAllReminders();
    alarmScheduler.scheduleMultipleReminders(reminders);
  };

  // Schedule alarms when reminders are loaded
  useEffect(() => {
    if (remindersQuery.data) {
      const activeReminders = remindersQuery.data.filter(r => r.isActive);
      alarmScheduler.scheduleMultipleReminders(activeReminders);
    }
  }, [remindersQuery.data]);

  const getStats = () => {
    const reminders = remindersQuery.data || [];
    const todayReminders = todayRemindersQuery.data || [];
    const upcomingReminders = upcomingRemindersQuery.data || [];

    return {
      total: reminders.length,
      today: todayReminders.length,
      upcoming: upcomingReminders.length,
    };
  };

  return {
    reminders: remindersQuery.data || [],
    todayReminders: todayRemindersQuery.data || [],
    upcomingReminders: upcomingRemindersQuery.data || [],
    isLoading: remindersQuery.isLoading,
    stats: getStats(),
    createReminder: createReminderMutation.mutate,
    updateReminder: updateReminderMutation.mutate,
    deleteReminder: deleteReminderMutation.mutate,
    clearAllReminders: clearAllRemindersMutation.mutate,
    isCreating: createReminderMutation.isPending,
    isUpdating: updateReminderMutation.isPending,
    isDeleting: deleteReminderMutation.isPending,
  };
}
