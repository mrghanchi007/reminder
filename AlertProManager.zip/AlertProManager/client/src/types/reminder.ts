export interface Reminder {
  id: string;
  title: string;
  description?: string;
  datetime: Date;
  repeat: 'once' | 'daily' | 'weekly' | 'monthly' | 'custom';
  alarmTone: 'default' | 'classic' | 'melody' | 'urgent';
  volume: number;
  priority: 'normal' | 'high';
  vibration: boolean;
  snoozeDelay: number;
  isActive: boolean;
  createdAt: Date;
}

export interface AlarmTriggerData {
  id: string;
  title: string;
  description?: string;
  time: string;
  priority: 'normal' | 'high';
  alarmTone: string;
  volume: number;
  vibration: boolean;
  snoozeDelay: number;
}

export interface AppSettings {
  notifications: boolean;
  timeFormat: '12' | '24';
  autoSnooze: boolean;
  theme: 'light' | 'dark';
}
