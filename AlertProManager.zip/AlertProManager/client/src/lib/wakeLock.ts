class WakeLockManager {
  private wakeLock: WakeLockSentinel | null = null;

  async requestWakeLock(): Promise<void> {
    if (!('wakeLock' in navigator)) {
      console.warn('Wake Lock API not supported');
      return;
    }

    try {
      this.wakeLock = await navigator.wakeLock.request('screen');
      
      this.wakeLock.addEventListener('release', () => {
        console.log('Wake lock was released');
      });

      console.log('Wake lock is active');
    } catch (error) {
      console.error('Failed to request wake lock:', error);
    }
  }

  async releaseWakeLock(): Promise<void> {
    if (this.wakeLock) {
      await this.wakeLock.release();
      this.wakeLock = null;
      console.log('Wake lock released');
    }
  }

  isWakeLockActive(): boolean {
    return this.wakeLock !== null && !this.wakeLock.released;
  }
}

export const wakeLockManager = new WakeLockManager();
