import Dexie, { Table } from 'dexie';
import { Reminder, AppSettings } from '../types/reminder';

export class AppDatabase extends Dexie {
  reminders!: Table<Reminder>;
  settings!: Table<AppSettings>;

  constructor() {
    super('AlertProDatabase');
    
    this.version(1).stores({
      reminders: 'id, title, datetime, repeat, priority, isActive',
      settings: 'theme, notifications, timeFormat, autoSnooze'
    });
  }
}

export const db = new AppDatabase();

// Database operations
export const reminderService = {
  async getAll(): Promise<Reminder[]> {
    return await db.reminders.orderBy('datetime').toArray();
  },

  async getActive(): Promise<Reminder[]> {
    return await db.reminders.where('isActive').equals(1).toArray();
  },

  async getTodaysReminders(): Promise<Reminder[]> {
    const today = new Date();
    const startOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    const endOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1);
    
    return await db.reminders
      .where('datetime')
      .between(startOfDay, endOfDay)
      .and(reminder => reminder.isActive)
      .toArray();
  },

  async getUpcomingReminders(): Promise<Reminder[]> {
    const now = new Date();
    return await db.reminders
      .where('datetime')
      .above(now)
      .and(reminder => reminder.isActive)
      .limit(10)
      .toArray();
  },

  async create(reminder: Omit<Reminder, 'id' | 'createdAt'>): Promise<string> {
    const id = crypto.randomUUID();
    const newReminder: Reminder = {
      ...reminder,
      id,
      createdAt: new Date()
    };
    await db.reminders.add(newReminder);
    return id;
  },

  async update(id: string, changes: Partial<Reminder>): Promise<void> {
    await db.reminders.update(id, changes);
  },

  async delete(id: string): Promise<void> {
    await db.reminders.delete(id);
  },

  async clear(): Promise<void> {
    await db.reminders.clear();
  }
};

export const settingsService = {
  async get(): Promise<AppSettings> {
    const settings = await db.settings.toArray();
    if (settings.length === 0) {
      const defaultSettings: AppSettings = {
        notifications: true,
        timeFormat: '12',
        autoSnooze: false,
        theme: 'light'
      };
      await db.settings.add(defaultSettings);
      return defaultSettings;
    }
    return settings[0];
  },

  async update(changes: Partial<AppSettings>): Promise<void> {
    const settings = await this.get();
    const updatedSettings = { ...settings, ...changes };
    await db.settings.clear();
    await db.settings.add(updatedSettings);
  }
};

// Export/Import functionality
export const dataService = {
  async exportReminders(): Promise<string> {
    const reminders = await reminderService.getAll();
    return JSON.stringify(reminders, null, 2);
  },

  async importReminders(jsonData: string): Promise<void> {
    try {
      const reminders: Reminder[] = JSON.parse(jsonData);
      await db.reminders.clear();
      for (const reminder of reminders) {
        await db.reminders.add({
          ...reminder,
          datetime: new Date(reminder.datetime),
          createdAt: new Date(reminder.createdAt)
        });
      }
    } catch (error) {
      throw new Error('Invalid JSON format');
    }
  }
};
