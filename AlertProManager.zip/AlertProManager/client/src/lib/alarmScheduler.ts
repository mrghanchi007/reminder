import { Reminder, AlarmTriggerData } from '../types/reminder';
import { audioManager } from './audioManager';
import { wakeLockManager } from './wakeLock';

type AlarmCallback = (alarmData: AlarmTriggerData) => void;

class AlarmScheduler {
  private scheduledAlarms = new Map<string, NodeJS.Timeout>();
  private alarmCallback: AlarmCallback | null = null;

  setAlarmCallback(callback: AlarmCallback): void {
    this.alarmCallback = callback;
  }

  scheduleReminder(reminder: Reminder): void {
    if (!reminder.isActive) return;

    const now = new Date();
    const alarmTime = new Date(reminder.datetime);
    
    if (alarmTime <= now) return; // Don't schedule past alarms

    const timeUntilAlarm = alarmTime.getTime() - now.getTime();
    
    // Clear any existing alarm for this reminder
    this.cancelReminder(reminder.id);

    const timeoutId = setTimeout(() => {
      this.triggerAlarm(reminder);
    }, timeUntilAlarm);

    this.scheduledAlarms.set(reminder.id, timeoutId);
  }

  scheduleMultipleReminders(reminders: Reminder[]): void {
    for (const reminder of reminders) {
      this.scheduleReminder(reminder);
    }
  }

  cancelReminder(reminderId: string): void {
    const timeoutId = this.scheduledAlarms.get(reminderId);
    if (timeoutId) {
      clearTimeout(timeoutId);
      this.scheduledAlarms.delete(reminderId);
    }
  }

  cancelAllReminders(): void {
    this.scheduledAlarms.forEach((timeoutId) => {
      clearTimeout(timeoutId);
    });
    this.scheduledAlarms.clear();
  }

  private async triggerAlarm(reminder: Reminder): Promise<void> {
    const alarmData: AlarmTriggerData = {
      id: reminder.id,
      title: reminder.title,
      description: reminder.description,
      time: this.formatTime(reminder.datetime),
      priority: reminder.priority,
      alarmTone: reminder.alarmTone as string,
      volume: reminder.volume,
      vibration: reminder.vibration,
      snoozeDelay: reminder.snoozeDelay
    };

    // Acquire wake lock to keep screen on
    await wakeLockManager.requestWakeLock();

    // Play alarm sound
    await audioManager.playAlarm(alarmData);

    // Trigger vibration if enabled
    if (reminder.vibration && 'vibrate' in navigator) {
      navigator.vibrate([1000, 500, 1000, 500, 1000]);
    }

    // Call the alarm callback (typically shows the alarm modal)
    if (this.alarmCallback) {
      this.alarmCallback(alarmData);
    }

    // Handle recurring reminders
    this.handleRecurringReminder(reminder);

    // Remove the scheduled alarm since it has triggered
    this.scheduledAlarms.delete(reminder.id);
  }

  private handleRecurringReminder(reminder: Reminder): void {
    if (reminder.repeat === 'once') return;

    const nextAlarmTime = this.calculateNextAlarmTime(reminder);
    if (nextAlarmTime) {
      const updatedReminder: Reminder = {
        ...reminder,
        datetime: nextAlarmTime
      };
      this.scheduleReminder(updatedReminder);
    }
  }

  private calculateNextAlarmTime(reminder: Reminder): Date | null {
    const currentTime = new Date(reminder.datetime);
    
    switch (reminder.repeat) {
      case 'daily':
        return new Date(currentTime.getTime() + 24 * 60 * 60 * 1000);
      
      case 'weekly':
        return new Date(currentTime.getTime() + 7 * 24 * 60 * 60 * 1000);
      
      case 'monthly':
        const nextMonth = new Date(currentTime);
        nextMonth.setMonth(nextMonth.getMonth() + 1);
        return nextMonth;
      
      default:
        return null;
    }
  }

  snoozeAlarm(alarmData: AlarmTriggerData): void {
    const snoozeTime = new Date(Date.now() + alarmData.snoozeDelay * 60 * 1000);
    
    const timeoutId = setTimeout(() => {
      this.triggerAlarm({
        id: alarmData.id,
        title: alarmData.title,
        description: alarmData.description,
        datetime: snoozeTime,
        repeat: 'once',
        alarmTone: alarmData.alarmTone as any,
        volume: alarmData.volume,
        priority: alarmData.priority,
        vibration: alarmData.vibration,
        snoozeDelay: alarmData.snoozeDelay,
        isActive: true,
        createdAt: new Date()
      });
    }, alarmData.snoozeDelay * 60 * 1000);

    this.scheduledAlarms.set(`snooze-${alarmData.id}`, timeoutId);
  }

  stopAlarm(): void {
    audioManager.stopAlarm();
    wakeLockManager.releaseWakeLock();
  }

  private formatTime(date: Date): string {
    return date.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  }

  getScheduledAlarms(): string[] {
    return Array.from(this.scheduledAlarms.keys());
  }
}

export const alarmScheduler = new AlarmScheduler();
