import { AlarmTriggerData } from '../types/reminder';

class AudioManager {
  private audioContext: AudioContext | null = null;
  private gainNode: GainNode | null = null;
  private currentAudio: HTMLAudioElement | null = null;
  private isPlaying = false;

  async initialize(): Promise<void> {
    if (this.audioContext) return;

    try {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      this.gainNode = this.audioContext.createGain();
      this.gainNode.connect(this.audioContext.destination);
    } catch (error) {
      console.error('Failed to initialize audio context:', error);
    }
  }

  async playAlarm(alarmData: AlarmTriggerData): Promise<void> {
    await this.initialize();
    
    if (!this.audioContext || !this.gainNode) {
      console.error('Audio context not initialized');
      return;
    }

    // Resume audio context if suspended
    if (this.audioContext.state === 'suspended') {
      await this.audioContext.resume();
    }

    // Stop any currently playing alarm
    this.stopAlarm();

    try {
      // Create audio element
      this.currentAudio = new Audio(this.getAlarmToneUrl(alarmData.alarmTone));
      this.currentAudio.loop = true;
      this.currentAudio.crossOrigin = 'anonymous';

      // Set volume based on priority and user setting
      const volume = alarmData.priority === 'high' ? 1.0 : alarmData.volume / 100;
      this.gainNode.gain.value = volume;

      // Create audio source and connect to gain node
      const source = this.audioContext.createMediaElementSource(this.currentAudio);
      source.connect(this.gainNode);

      // Play the audio
      await this.currentAudio.play();
      this.isPlaying = true;

      // Handle audio end (though it should loop)
      this.currentAudio.addEventListener('ended', () => {
        if (this.isPlaying) {
          this.currentAudio?.play();
        }
      });

    } catch (error) {
      console.error('Failed to play alarm:', error);
      // Fallback: try to play without Web Audio API
      this.playFallbackAlarm(alarmData);
    }
  }

  private async playFallbackAlarm(alarmData: AlarmTriggerData): Promise<void> {
    try {
      this.currentAudio = new Audio(this.getAlarmToneUrl(alarmData.alarmTone));
      this.currentAudio.loop = true;
      this.currentAudio.volume = alarmData.priority === 'high' ? 1.0 : alarmData.volume / 100;
      await this.currentAudio.play();
      this.isPlaying = true;
    } catch (error) {
      console.error('Fallback alarm playback failed:', error);
    }
  }

  stopAlarm(): void {
    if (this.currentAudio) {
      this.currentAudio.pause();
      this.currentAudio.currentTime = 0;
      this.currentAudio = null;
    }
    this.isPlaying = false;
  }

  setVolume(volume: number): void {
    if (this.gainNode) {
      this.gainNode.gain.value = volume / 100;
    } else if (this.currentAudio) {
      this.currentAudio.volume = volume / 100;
    }
  }

  private getAlarmToneUrl(tone: string): string {
    // Using data URLs for built-in tones to ensure offline capability
    const tones = {
      default: 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBjeN2O/QfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJr',
      classic: 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBjeN2O/QfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmzhBjeM2e/PfDEGJXnJr',
      melody: 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBjeN2O/QfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmzhBjeM2e/PfDEGJXnJr',
      urgent: 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBjeN2O/QfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmzhBjeM2e/PfDEGJXnJr'
    };
    
    return tones[tone as keyof typeof tones] || tones.default;
  }

  async preloadTones(): Promise<void> {
    const tones = ['default', 'classic', 'melody', 'urgent'];
    for (const tone of tones) {
      try {
        const audio = new Audio(this.getAlarmToneUrl(tone));
        audio.load();
      } catch (error) {
        console.warn(`Failed to preload tone: ${tone}`, error);
      }
    }
  }

  isCurrentlyPlaying(): boolean {
    return this.isPlaying;
  }

  async playTonePreview(tone: string, volume: number = 50): Promise<void> {
    try {
      const audio = new Audio(this.getAlarmToneUrl(tone));
      audio.volume = volume / 100;
      audio.currentTime = 0;
      
      // Play for 2 seconds then stop
      await audio.play();
      setTimeout(() => {
        audio.pause();
        audio.currentTime = 0;
      }, 2000);
    } catch (error) {
      console.warn('Could not play tone preview:', error);
    }
  }
}

export const audioManager = new AudioManager();
