import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Home, Clock, Settings, Menu, Moon, Sun } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { StatsCards } from '../components/StatsCards';
import { CalendarView } from '../components/CalendarView';
import { TimelineView } from '../components/TimelineView';
import { NewReminderModal } from '../components/NewReminderModal';
import { SettingsModal } from '../components/SettingsModal';
import { AlarmModal } from '../components/AlarmModal';
import { useThemeContext } from '../components/ThemeProvider';
import { useReminders } from '../hooks/use-reminders';
import { alarmScheduler } from '../lib/alarmScheduler';
import { audioManager } from '../lib/audioManager';
import { AlarmTriggerData } from '../types/reminder';

export default function HomePage() {
  const { theme, toggleTheme } = useThemeContext();
  const [viewMode, setViewMode] = useState<'calendar' | 'timeline'>('calendar');
  const [showNewReminderModal, setShowNewReminderModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [showAlarmModal, setShowAlarmModal] = useState(false);
  const [currentAlarm, setCurrentAlarm] = useState<AlarmTriggerData | null>(null);

  useEffect(() => {
    // Initialize audio manager
    audioManager.initialize();
    audioManager.preloadTones();

    // Set up alarm callback
    alarmScheduler.setAlarmCallback((alarmData) => {
      setCurrentAlarm(alarmData);
      setShowAlarmModal(true);
    });

    // Request notification permission
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }

    return () => {
      alarmScheduler.stopAlarm();
    };
  }, []);

  const handleAlarmClose = () => {
    setShowAlarmModal(false);
    setCurrentAlarm(null);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg px-4 py-3 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between max-w-md mx-auto">
          <div className="flex items-center space-x-3">
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center"
            >
              <Clock className="w-5 h-5 text-white" />
            </motion.div>
            <h1 className="text-xl font-bold">AlertPro+</h1>
          </div>
          
          <div className="flex items-center space-x-2">
            {/* Theme Toggle Button */}
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleTheme}
              className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
            >
              {theme === 'dark' ? (
                <Sun className="w-5 h-5" />
              ) : (
                <Moon className="w-5 h-5" />
              )}
            </Button>
            
            {/* Menu Button */}
            <Button
              variant="ghost"
              size="sm"
              className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
            >
              <Menu className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="pb-20">
        {/* Stats Cards */}
        <StatsCards />

        {/* View Toggle */}
        <section className="px-4 mb-6">
          <div className="max-w-md mx-auto">
            <div className="bg-gray-100 dark:bg-gray-800 p-1 rounded-xl flex">
              <Button
                variant={viewMode === 'calendar' ? 'default' : 'ghost'}
                onClick={() => setViewMode('calendar')}
                className="flex-1 py-2 px-4 rounded-lg transition-all"
              >
                Calendar
              </Button>
              <Button
                variant={viewMode === 'timeline' ? 'default' : 'ghost'}
                onClick={() => setViewMode('timeline')}
                className="flex-1 py-2 px-4 rounded-lg transition-all"
              >
                Timeline
              </Button>
            </div>
          </div>
        </section>

        {/* View Content */}
        <AnimatePresence mode="wait">
          {viewMode === 'calendar' ? (
            <motion.div
              key="calendar"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.2 }}
            >
              <CalendarView />
            </motion.div>
          ) : (
            <motion.div
              key="timeline"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
            >
              <TimelineView />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Floating Action Button */}
      <motion.div
        className="fixed bottom-20 right-4 z-40"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <Button
          onClick={() => setShowNewReminderModal(true)}
          size="lg"
          className="w-14 h-14 rounded-full bg-primary hover:bg-primary/90 shadow-lg hover:shadow-xl transition-all duration-200"
        >
          <Plus className="w-6 h-6" />
        </Button>
      </motion.div>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-t border-gray-200 dark:border-gray-700">
        <div className="flex justify-around py-2">
          <Button
            variant="ghost"
            className="flex flex-col items-center py-2 px-4 text-primary"
          >
            <Home className="w-6 h-6" />
            <span className="text-xs mt-1 font-medium">Home</span>
          </Button>
          
          <Button
            variant="ghost"
            onClick={() => setViewMode(viewMode === 'calendar' ? 'timeline' : 'calendar')}
            className="flex flex-col items-center py-2 px-4 text-gray-600 dark:text-gray-400"
          >
            <Clock className="w-6 h-6" />
            <span className="text-xs mt-1">
              {viewMode === 'calendar' ? 'Timeline' : 'Calendar'}
            </span>
          </Button>
          
          <Button
            variant="ghost"
            onClick={() => setShowSettingsModal(true)}
            className="flex flex-col items-center py-2 px-4 text-gray-600 dark:text-gray-400"
          >
            <Settings className="w-6 h-6" />
            <span className="text-xs mt-1">Settings</span>
          </Button>
        </div>
      </nav>

      {/* Footer */}
      <footer className="text-center py-4 text-sm text-gray-500 dark:text-gray-400 border-t border-gray-200 dark:border-gray-700 mt-8">
        Powered by{' '}
        <a
          href="https://www.account4web.ca"
          target="_blank"
          rel="noopener noreferrer"
          className="text-primary hover:underline"
        >
          Account4Web Inc
        </a>
      </footer>

      {/* Modals */}
      <NewReminderModal
        isOpen={showNewReminderModal}
        onClose={() => setShowNewReminderModal(false)}
      />
      
      <SettingsModal
        isOpen={showSettingsModal}
        onClose={() => setShowSettingsModal(false)}
      />
      
      <AlarmModal
        isOpen={showAlarmModal}
        alarmData={currentAlarm}
        onClose={handleAlarmClose}
      />
    </div>
  );
}
