import { motion } from 'framer-motion';
import { MoreVertical } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useReminders } from '../hooks/use-reminders';
import { format, isToday, isTomorrow, startOfDay, endOfDay } from 'date-fns';

export function TimelineView() {
  const { reminders } = useReminders();

  const getTodayReminders = () => {
    const today = new Date();
    return reminders.filter(reminder => 
      isToday(new Date(reminder.datetime)) && reminder.isActive
    );
  };

  const getTomorrowReminders = () => {
    return reminders.filter(reminder => 
      isTomorrow(new Date(reminder.datetime)) && reminder.isActive
    );
  };

  const getThisWeekReminders = () => {
    const now = new Date();
    const weekFromNow = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
    
    return reminders.filter(reminder => {
      const reminderDate = new Date(reminder.datetime);
      return reminderDate > new Date(now.getTime() + 2 * 24 * 60 * 60 * 1000) && 
             reminderDate <= weekFromNow && 
             reminder.isActive;
    });
  };

  const formatTime = (date: Date) => {
    return format(date, 'h:mm a');
  };

  const formatDateTime = (date: Date) => {
    return format(date, 'MMM d, h:mm a');
  };

  const getPriorityColor = (priority: string) => {
    return priority === 'high' ? 'text-red-500' : 'text-primary';
  };

  const getPriorityBg = (priority: string) => {
    return priority === 'high' ? 'bg-red-100 dark:bg-red-900/30' : 'bg-primary/10';
  };

  const todayReminders = getTodayReminders();
  const tomorrowReminders = getTomorrowReminders();
  const thisWeekReminders = getThisWeekReminders();

  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="px-4 mb-6"
    >
      <div className="max-w-md mx-auto space-y-6">
        
        {/* Today Section */}
        {todayReminders.length > 0 && (
          <div>
            <h3 className="text-lg font-semibold mb-3 text-gray-900 dark:text-white">Today</h3>
            <div className="space-y-3">
              {todayReminders.map((reminder, index) => (
                <motion.div
                  key={reminder.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900 dark:text-white">
                        {reminder.title}
                      </h4>
                      {reminder.description && (
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                          {reminder.description}
                        </p>
                      )}
                      <div className="flex items-center space-x-3 mt-2">
                        <span className={`text-sm font-medium ${getPriorityColor(reminder.priority)}`}>
                          {formatTime(new Date(reminder.datetime))}
                        </span>
                        <span className={`text-xs px-2 py-1 rounded-full ${getPriorityBg(reminder.priority)} ${getPriorityColor(reminder.priority)}`}>
                          {reminder.priority === 'high' ? 'High Priority' : 'Normal'}
                        </span>
                        {reminder.repeat !== 'once' && (
                          <span className="text-xs px-2 py-1 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-full">
                            Repeats {reminder.repeat}
                          </span>
                        )}
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                    >
                      <MoreVertical className="w-5 h-5" />
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* Tomorrow Section */}
        {tomorrowReminders.length > 0 && (
          <div>
            <h3 className="text-lg font-semibold mb-3 text-gray-900 dark:text-white">Tomorrow</h3>
            <div className="space-y-3">
              {tomorrowReminders.map((reminder, index) => (
                <motion.div
                  key={reminder.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900 dark:text-white">
                        {reminder.title}
                      </h4>
                      {reminder.description && (
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                          {reminder.description}
                        </p>
                      )}
                      <div className="flex items-center space-x-3 mt-2">
                        <span className={`text-sm font-medium ${getPriorityColor(reminder.priority)}`}>
                          {formatTime(new Date(reminder.datetime))}
                        </span>
                        <span className={`text-xs px-2 py-1 rounded-full ${getPriorityBg(reminder.priority)} ${getPriorityColor(reminder.priority)}`}>
                          {reminder.priority === 'high' ? 'High Priority' : 'Normal'}
                        </span>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                    >
                      <MoreVertical className="w-5 h-5" />
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* This Week Section */}
        {thisWeekReminders.length > 0 && (
          <div>
            <h3 className="text-lg font-semibold mb-3 text-gray-900 dark:text-white">This Week</h3>
            <div className="space-y-3">
              {thisWeekReminders.map((reminder, index) => (
                <motion.div
                  key={reminder.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white dark:bg-gray-800 rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900 dark:text-white">
                        {reminder.title}
                      </h4>
                      {reminder.description && (
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                          {reminder.description}
                        </p>
                      )}
                      <div className="flex items-center space-x-3 mt-2">
                        <span className={`text-sm font-medium ${getPriorityColor(reminder.priority)}`}>
                          {formatDateTime(new Date(reminder.datetime))}
                        </span>
                        <span className={`text-xs px-2 py-1 rounded-full ${getPriorityBg(reminder.priority)} ${getPriorityColor(reminder.priority)}`}>
                          {reminder.priority === 'high' ? 'High Priority' : 'Normal'}
                        </span>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                    >
                      <MoreVertical className="w-5 h-5" />
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* Empty State */}
        {todayReminders.length === 0 && tomorrowReminders.length === 0 && thisWeekReminders.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <div className="text-gray-400 dark:text-gray-500 mb-2">
              <svg className="w-16 h-16 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No upcoming reminders</h3>
            <p className="text-gray-600 dark:text-gray-400">Tap the + button to create your first reminder</p>
          </motion.div>
        )}
      </div>
    </motion.section>
  );
}
