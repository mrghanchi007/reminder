import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Download, Upload, Trash2, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { useThemeContext } from './ThemeProvider';
import { settingsService, dataService } from '../lib/db';
import { useReminders } from '../hooks/use-reminders';
import { useToast } from '../hooks/use-toast';
import { AppSettings } from '../types/reminder';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SettingsModal({ isOpen, onClose }: SettingsModalProps) {
  const { theme, toggleTheme } = useThemeContext();
  const { clearAllReminders } = useReminders();
  const { toast } = useToast();
  
  const [settings, setSettings] = useState<AppSettings>({
    notifications: true,
    timeFormat: '12',
    autoSnooze: false,
    theme: 'light'
  });

  useEffect(() => {
    if (isOpen) {
      loadSettings();
    }
  }, [isOpen]);

  const loadSettings = async () => {
    try {
      const currentSettings = await settingsService.get();
      setSettings(currentSettings);
    } catch (error) {
      console.error('Failed to load settings:', error);
    }
  };

  const updateSetting = async (key: keyof AppSettings, value: any) => {
    try {
      const newSettings = { ...settings, [key]: value };
      setSettings(newSettings);
      await settingsService.update({ [key]: value });
      
      if (key === 'theme') {
        toggleTheme();
      }
    } catch (error) {
      console.error('Failed to update setting:', error);
      toast({ title: "Failed to update setting", variant: "destructive" });
    }
  };

  const handleExport = async () => {
    try {
      const jsonData = await dataService.exportReminders();
      const blob = new Blob([jsonData], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      
      const a = document.createElement('a');
      a.href = url;
      a.download = `alertpro-reminders-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast({ title: "Reminders exported successfully!" });
    } catch (error) {
      console.error('Export failed:', error);
      toast({ title: "Failed to export reminders", variant: "destructive" });
    }
  };

  const handleImport = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;
      
      try {
        const text = await file.text();
        await dataService.importReminders(text);
        toast({ title: "Reminders imported successfully!" });
      } catch (error) {
        console.error('Import failed:', error);
        toast({ title: "Failed to import reminders", variant: "destructive" });
      }
    };
    
    input.click();
  };

  const handleClearData = async () => {
    if (confirm('Are you sure you want to clear all reminders? This action cannot be undone.')) {
      try {
        clearAllReminders();
        toast({ title: "All reminders cleared" });
      } catch (error) {
        console.error('Clear data failed:', error);
        toast({ title: "Failed to clear data", variant: "destructive" });
      }
    }
  };

  const requestNotificationPermission = async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      await updateSetting('notifications', permission === 'granted');
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onClick={onClose}
          />
          <motion.div
            initial={{ y: '100%', opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: '100%', opacity: 0 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="relative w-full max-w-md bg-white dark:bg-gray-800 rounded-t-3xl max-h-[80vh] overflow-y-auto"
          >
            {/* Header */}
            <div className="sticky top-0 bg-white dark:bg-gray-800 px-6 py-4 border-b border-gray-200 dark:border-gray-700 rounded-t-3xl">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold">Settings</h2>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onClose}
                  className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  <X className="w-6 h-6" />
                </Button>
              </div>
            </div>

            {/* Settings Content */}
            <div className="p-6 space-y-6">
              
              {/* App Settings */}
              <div>
                <h3 className="text-lg font-semibold mb-4">App Settings</h3>
                <div className="space-y-4">
                  
                  <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-xl">
                    <div>
                      <div className="font-medium">Notifications</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">Enable push notifications</div>
                    </div>
                    <Switch
                      checked={settings.notifications}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          requestNotificationPermission();
                        } else {
                          updateSetting('notifications', false);
                        }
                      }}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-xl">
                    <div>
                      <div className="font-medium">24-Hour Format</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">Use 24-hour time format</div>
                    </div>
                    <Switch
                      checked={settings.timeFormat === '24'}
                      onCheckedChange={(checked) => updateSetting('timeFormat', checked ? '24' : '12')}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-xl">
                    <div>
                      <div className="font-medium">Auto Snooze</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">Automatically snooze after 1 minute</div>
                    </div>
                    <Switch
                      checked={settings.autoSnooze}
                      onCheckedChange={(checked) => updateSetting('autoSnooze', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-xl">
                    <div>
                      <div className="font-medium">Dark Mode</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">Toggle dark theme</div>
                    </div>
                    <Switch
                      checked={theme === 'dark'}
                      onCheckedChange={toggleTheme}
                    />
                  </div>
                </div>
              </div>

              {/* Data Management */}
              <div>
                <h3 className="text-lg font-semibold mb-4">Data Management</h3>
                <div className="space-y-3">
                  
                  <Button
                    onClick={handleExport}
                    variant="outline"
                    className="w-full p-4 h-auto justify-between bg-primary/5 hover:bg-primary/10 border-primary/20"
                  >
                    <div className="flex items-center space-x-3">
                      <Download className="w-5 h-5 text-primary" />
                      <span className="font-medium text-primary">Export Reminders</span>
                    </div>
                    <ChevronRight className="w-5 h-5 text-primary" />
                  </Button>
                  
                  <Button
                    onClick={handleImport}
                    variant="outline"
                    className="w-full p-4 h-auto justify-between bg-green-50 dark:bg-green-900/20 hover:bg-green-100 dark:hover:bg-green-900/30 border-green-200 dark:border-green-800"
                  >
                    <div className="flex items-center space-x-3">
                      <Upload className="w-5 h-5 text-green-600 dark:text-green-400" />
                      <span className="font-medium text-green-600 dark:text-green-400">Import Reminders</span>
                    </div>
                    <ChevronRight className="w-5 h-5 text-green-600 dark:text-green-400" />
                  </Button>
                  
                  <Button
                    onClick={handleClearData}
                    variant="outline"
                    className="w-full p-4 h-auto justify-between bg-red-50 dark:bg-red-900/20 hover:bg-red-100 dark:hover:bg-red-900/30 border-red-200 dark:border-red-800"
                  >
                    <div className="flex items-center space-x-3">
                      <Trash2 className="w-5 h-5 text-red-600 dark:text-red-400" />
                      <span className="font-medium text-red-600 dark:text-red-400">Clear All Data</span>
                    </div>
                    <ChevronRight className="w-5 h-5 text-red-600 dark:text-red-400" />
                  </Button>
                </div>
              </div>

              {/* About */}
              <div>
                <h3 className="text-lg font-semibold mb-4">About</h3>
                <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-xl space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Version</span>
                    <span className="font-medium">1.0.0</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Build</span>
                    <span className="font-medium">2024.12.15</span>
                  </div>
                  <div className="pt-2 border-t border-gray-200 dark:border-gray-600">
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Smart alarm and reminder PWA designed for mobile and desktop use.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
