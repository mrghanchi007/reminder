import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Clock, Volume2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { AlarmTriggerData } from '../types/reminder';
import { audioManager } from '../lib/audioManager';
import { alarmScheduler } from '../lib/alarmScheduler';
import { wakeLockManager } from '../lib/wakeLock';

interface AlarmModalProps {
  isOpen: boolean;
  alarmData: AlarmTriggerData | null;
  onClose: () => void;
}

export function AlarmModal({ isOpen, alarmData, onClose }: AlarmModalProps) {
  const [volume, setVolume] = useState(50);

  useEffect(() => {
    if (isOpen && alarmData) {
      setVolume(alarmData.volume);
    }
  }, [isOpen, alarmData]);

  const handleVolumeChange = (newVolume: number[]) => {
    const vol = newVolume[0];
    setVolume(vol);
    audioManager.setVolume(vol);
  };

  const handleSnooze = async () => {
    if (!alarmData) return;
    
    alarmScheduler.stopAlarm();
    alarmScheduler.snoozeAlarm(alarmData);
    onClose();
  };

  const handleStop = () => {
    alarmScheduler.stopAlarm();
    onClose();
  };

  if (!alarmData) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex flex-col items-center justify-center p-6 text-center"
          style={{
            background: alarmData.priority === 'high' 
              ? 'linear-gradient(45deg, rgba(239, 68, 68, 0.9), rgba(220, 38, 38, 0.9))'
              : 'linear-gradient(45deg, rgba(99, 102, 241, 0.9), rgba(79, 70, 229, 0.9))'
          }}
        >
          {/* Animated background effect */}
          <div className="absolute inset-0 opacity-20">
            <motion.div
              animate={{
                scale: [1, 1.1, 1],
                opacity: [0.3, 0.6, 0.3]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="w-full h-full bg-white rounded-full blur-3xl"
            />
          </div>

          {/* Alarm Icon */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', damping: 10 }}
            className="w-24 h-24 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mb-6 relative z-10"
          >
            <motion.div
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 0.5, repeat: Infinity }}
            >
              <Clock className="w-12 h-12 text-white" />
            </motion.div>
          </motion.div>

          {/* Alarm Details */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-white mb-8 relative z-10"
          >
            <h2 className="text-3xl font-bold mb-2">{alarmData.title}</h2>
            <p className="text-xl opacity-90 mb-2">{alarmData.time}</p>
            {alarmData.description && (
              <p className="text-lg opacity-70">{alarmData.description}</p>
            )}
          </motion.div>

          {/* Action Buttons */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="flex space-x-4 w-full max-w-sm mb-6 relative z-10"
          >
            <Button
              onClick={handleSnooze}
              className="flex-1 py-4 px-6 bg-white/20 backdrop-blur-sm text-white border border-white/30 rounded-2xl font-semibold text-lg hover:bg-white/30 transition-all"
            >
              Snooze ({alarmData.snoozeDelay}m)
            </Button>
            <Button
              onClick={handleStop}
              className="flex-1 py-4 px-6 bg-white text-gray-900 rounded-2xl font-semibold text-lg hover:bg-gray-100 transition-all shadow-lg"
            >
              Stop
            </Button>
          </motion.div>

          {/* Volume Control */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="w-full max-w-sm relative z-10"
          >
            <div className="flex items-center space-x-4 bg-white/10 backdrop-blur-sm rounded-xl p-4">
              <Volume2 className="w-5 h-5 text-white" />
              <Slider
                value={[volume]}
                onValueChange={handleVolumeChange}
                min={0}
                max={100}
                step={5}
                className="flex-1"
              />
              <span className="text-white font-medium w-12">{volume}%</span>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
