import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Volume2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { useReminders } from '../hooks/use-reminders';
import { audioManager } from '../lib/audioManager';
import { useToast } from '../hooks/use-toast';

interface NewReminderModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function NewReminderModal({ isOpen, onClose }: NewReminderModalProps) {
  const { createReminder, isCreating } = useReminders();
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    date: '',
    time: '',
    repeat: 'once',
    alarmTone: 'default',
    volume: 50,
    priority: 'normal',
    vibration: true,
    snoozeDelay: 10
  });

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const playTonePreview = async (tone: string) => {
    try {
      await audioManager.initialize();
      const audio = new Audio();
      const toneUrls = {
        default: 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBjeN2O/QfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJr',
        classic: 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBjeN2O/QfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJr',
        melody: 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBjeN2O/QfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmzhBjeM2e/PfDEGJXnJr',
        urgent: 'data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBjeN2O/QfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjeM2e/PfDEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmwhBjEGJXnJ8N2QQAoUXrTp66hVFApGn+DyvmzhBjeM2e/PfDEGJXnJr'
      };
      
      audio.src = toneUrls[tone as keyof typeof toneUrls] || toneUrls.default;
      audio.volume = formData.volume / 100;
      await audio.play();
      
      setTimeout(() => {
        audio.pause();
        audio.currentTime = 0;
      }, 1000);
    } catch (error) {
      console.warn('Could not play tone preview:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title.trim()) {
      toast({ title: "Title is required", variant: "destructive" });
      return;
    }
    
    if (!formData.date || !formData.time) {
      toast({ title: "Date and time are required", variant: "destructive" });
      return;
    }

    const datetime = new Date(`${formData.date}T${formData.time}`);
    
    if (datetime <= new Date()) {
      toast({ title: "Please select a future date and time", variant: "destructive" });
      return;
    }

    try {
      createReminder({
        title: formData.title.trim(),
        description: formData.description.trim() || undefined,
        datetime,
        repeat: formData.repeat as any,
        alarmTone: formData.alarmTone as any,
        volume: formData.volume,
        priority: formData.priority as any,
        vibration: formData.vibration,
        snoozeDelay: formData.snoozeDelay,
        isActive: true,
      });

      toast({ title: "Reminder created successfully!" });
      handleClose();
    } catch (error) {
      toast({ title: "Failed to create reminder", variant: "destructive" });
    }
  };

  const handleClose = () => {
    setFormData({
      title: '',
      description: '',
      date: '',
      time: '',
      repeat: 'once',
      alarmTone: 'default',
      volume: 50,
      priority: 'normal',
      vibration: true,
      snoozeDelay: 10
    });
    onClose();
  };

  const toneOptions = [
    { value: 'default', label: '🔔 Default', emoji: '🔔' },
    { value: 'classic', label: '⏰ Classic', emoji: '⏰' },
    { value: 'melody', label: '🎵 Melody', emoji: '🎵' },
    { value: 'urgent', label: '📢 Urgent', emoji: '📢' }
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onClick={handleClose}
          />
          <motion.div
            initial={{ y: '100%', opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: '100%', opacity: 0 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="relative w-full max-w-md bg-white dark:bg-gray-800 rounded-t-3xl max-h-[90vh] overflow-y-auto"
          >
            {/* Header */}
            <div className="sticky top-0 bg-white dark:bg-gray-800 px-6 py-4 border-b border-gray-200 dark:border-gray-700 rounded-t-3xl">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold">New Reminder</h2>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleClose}
                  className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  <X className="w-6 h-6" />
                </Button>
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-6">
              {/* Title */}
              <div>
                <label className="block text-sm font-medium mb-2">Title</label>
                <Input
                  placeholder="Enter reminder title"
                  value={formData.title}
                  onChange={(e) => handleInputChange('title', e.target.value)}
                  className="w-full"
                />
              </div>

              {/* Description */}
              <div>
                <label className="block text-sm font-medium mb-2">Description</label>
                <Textarea
                  placeholder="Add notes or details..."
                  rows={3}
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  className="w-full resize-none"
                />
              </div>

              {/* Date & Time */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Date</label>
                  <Input
                    type="date"
                    value={formData.date}
                    onChange={(e) => handleInputChange('date', e.target.value)}
                    className="w-full"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Time</label>
                  <Input
                    type="time"
                    value={formData.time}
                    onChange={(e) => handleInputChange('time', e.target.value)}
                    className="w-full"
                  />
                </div>
              </div>

              {/* Repeat Options */}
              <div>
                <label className="block text-sm font-medium mb-2">Repeat</label>
                <Select value={formData.repeat} onValueChange={(value) => handleInputChange('repeat', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="once">Once</SelectItem>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Alarm Tone */}
              <div>
                <label className="block text-sm font-medium mb-2">Alarm Tone</label>
                <div className="grid grid-cols-2 gap-3">
                  {toneOptions.map((tone) => (
                    <Button
                      key={tone.value}
                      type="button"
                      variant={formData.alarmTone === tone.value ? "default" : "outline"}
                      onClick={() => {
                        handleInputChange('alarmTone', tone.value);
                        playTonePreview(tone.value);
                      }}
                      className="p-3 h-auto text-left"
                    >
                      <span className="text-base">{tone.emoji}</span>
                      <span className="ml-2 text-sm">{tone.label.split(' ')[1]}</span>
                    </Button>
                  ))}
                </div>
              </div>

              {/* Volume Control */}
              <div>
                <label className="block text-sm font-medium mb-2">Volume</label>
                <div className="flex items-center space-x-4">
                  <Volume2 className="w-5 h-5 text-gray-400" />
                  <Slider
                    value={[formData.volume]}
                    onValueChange={(value) => handleInputChange('volume', value[0])}
                    min={10}
                    max={100}
                    step={10}
                    className="flex-1"
                  />
                  <span className="text-sm font-medium w-12">{formData.volume}%</span>
                </div>
              </div>

              {/* Priority */}
              <div>
                <label className="block text-sm font-medium mb-2">Priority</label>
                <div className="flex space-x-3">
                  <Button
                    type="button"
                    variant={formData.priority === 'normal' ? "default" : "outline"}
                    onClick={() => handleInputChange('priority', 'normal')}
                    className="flex-1"
                  >
                    Normal
                  </Button>
                  <Button
                    type="button"
                    variant={formData.priority === 'high' ? "destructive" : "outline"}
                    onClick={() => handleInputChange('priority', 'high')}
                    className="flex-1"
                  >
                    High Priority
                  </Button>
                </div>
              </div>

              {/* Toggle Options */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Vibration</span>
                  <Switch
                    checked={formData.vibration}
                    onCheckedChange={(checked) => handleInputChange('vibration', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Snooze Delay</span>
                  <Select
                    value={formData.snoozeDelay.toString()}
                    onValueChange={(value) => handleInputChange('snoozeDelay', parseInt(value))}
                  >
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">5 minutes</SelectItem>
                      <SelectItem value="10">10 minutes</SelectItem>
                      <SelectItem value="15">15 minutes</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex space-x-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleClose}
                  className="flex-1"
                  disabled={isCreating}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="flex-1"
                  disabled={isCreating}
                >
                  {isCreating ? 'Saving...' : 'Save Reminder'}
                </Button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
