import { motion } from 'framer-motion';
import { useReminders } from '../hooks/use-reminders';

export function StatsCards() {
  const { stats } = useReminders();

  const cards = [
    {
      value: stats.total,
      label: 'Total',
      color: 'text-primary',
      bgColor: 'bg-primary/10'
    },
    {
      value: stats.today,
      label: 'Today',
      color: 'text-accent',
      bgColor: 'bg-accent/10'
    },
    {
      value: stats.upcoming,
      label: 'Upcoming',
      color: 'text-secondary',
      bgColor: 'bg-secondary/10'
    }
  ];

  return (
    <section className="px-4 pt-6">
      <div className="max-w-md mx-auto">
        <div className="grid grid-cols-3 gap-3 mb-6">
          {cards.map((card, index) => (
            <motion.div
              key={card.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white dark:bg-gray-800 rounded-xl p-3 shadow-sm hover:shadow-md transition-shadow"
            >
              <div className={`text-2xl font-bold ${card.color}`}>
                {card.value}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">
                {card.label}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
